

package com.bolao2022.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoBolao {

    public static void main(String[] args) {

        SpringApplication.run(ProjetoBolao.class, args);
        
    }
}
