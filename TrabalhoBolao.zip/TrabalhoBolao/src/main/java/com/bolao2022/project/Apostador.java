package com.bolao2022.project;

public class Apostador {
    private String nomeApostador;
    private int pontuacao;
    private int apostaGolsMandante;
    private int apostaGolsVisitante;
    private Time apostaVencedor;
    


    public Apostador(){

    }
    
    
    public Apostador(String nomeApostador, int apostaGolsMandante, int apostaGolsVisitante, Time apostaVencedor){
        this.nomeApostador = nomeApostador;
        this.pontuacao = 0;
        this.apostaGolsMandante = apostaGolsMandante;
        this.apostaGolsVisitante = apostaGolsVisitante;
        this.apostaVencedor = apostaVencedor;
    }
    
  
    
    public String getNomeApostador(){
        return nomeApostador;
    }
    
    public void setNomeApostador(String nomeApostador){
        this.nomeApostador = nomeApostador;
    }
    
    public int getPontuacao(){
        return pontuacao;
    }
    
    public void setPontuacao(int pontuacao){
        this.pontuacao = pontuacao;
    }

    public int getApostaGolsMandante() {
        return apostaGolsMandante;
    }

    public void setApostaGolsMandante(int apostaGolsMandante) {
        this.apostaGolsMandante = apostaGolsMandante;
    }

    public int getApostaGolsVisitante() {
        return apostaGolsVisitante;
    }

    public void setApostaGolsVisitante(int apostaGolsVisitante) {
        this.apostaGolsVisitante = apostaGolsVisitante;
    }

    public Time getApostaVencedor() {
        return apostaVencedor;
    }

    public void setApostaVencedor(Time apostaVencedor) {
        this.apostaVencedor = apostaVencedor;
    }
    
    
      @Override
    public String toString() {
        return "Apostador{" + "nomeApostador=" + nomeApostador + ", pontuacao=" + pontuacao + ", apostaGolsMandante=" + apostaGolsMandante + ", apostaGolsVisitante=" + apostaGolsVisitante + ", apostaVencedor=" + apostaVencedor + '}';
    }
    
    
    
}
