package com.bolao2022.project;

public class Bolao {
    private Jogo jogo;
    private Apostador apostador;
    
    
    public Bolao(){
        
    }
    
    public Bolao(Jogo jogo, Apostador apostador){
        this.jogo = jogo;
        this.apostador = apostador;
    }
    
    
    public void Resultado(){
        if(this.jogo.Vencedor()== this.apostador.getApostaVencedor()){
            this.apostador.setPontuacao(this.apostador.getPontuacao() + 5);
            
        } else if(this.apostador.getApostaGolsMandante()== this.jogo.getGolsMandante() && this.jogo.getGolsVisitante()==this.jogo.getGolsVisitante()){
            this.apostador.setPontuacao(this.apostador.getPontuacao() + 10);
            
        } else if(this.apostador.getApostaGolsMandante()== this.jogo.getGolsMandante() || this.jogo.getGolsVisitante()==this.jogo.getGolsVisitante()){
            this.apostador.setPontuacao(this.apostador.getPontuacao() + 2);
        }    
    }
   

    public Jogo getJogo() {
        return jogo;
    }

    public void setJogo(Jogo jogo) {
        this.jogo = jogo;
    }

    public Apostador getApostador() {
        return apostador;
    }

    public void setApostador(Apostador apostador) {
        this.apostador = apostador;
    }

    @Override
    public String toString() {
        return "Bolao{" + "jogo=" + jogo + ", apostador=" + apostador + '}';
    }
    
    
    
}
